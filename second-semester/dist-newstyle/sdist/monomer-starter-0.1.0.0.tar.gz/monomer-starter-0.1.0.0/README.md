# Monomer starter application

Starter application for the Monomer library, including:

- Dependencies
- Model and events type
- Event handler
- UI builder

For more information, check https://github.com/fjvallarino/monomer.
