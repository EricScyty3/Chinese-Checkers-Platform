module Minimax where
-- the module of the minimax search: Paranoid and BRS, with limited search depth and allow multiple players
-- the section aims to provide a helpful movement decision method during the playout phase

import Board
    ( appendColour,
      colourIndex,
      defaultMove,
      destinationList,
      getColour,
      getElement,
      goalBase,
      isOccupied,
      projectMove,
      removeByIdx,
      repaintPath,
      replace,
      reversion,
      Board,
      BoardPos,
      Colour,
      Pos,
      Transform )
import Control.Monad.State
    ( State, evalState, MonadState(put, get), runState )
import GameTree
    ( pairArrange, playerColour, turnBase, KillerMoves, PlayerIndex )
import Control.Parallel ( par, pseq )
import Zobrist ( flipBoard )
import Data.List ( elemIndex, nub, sortBy )
import Control.Monad.Extra ( concatMapM )
import BFS (centroid)
import Control.Parallel.Strategies (parMap, rseq)

-- the search tree can be categorized into two groups, the paranoid and BRS forms
-- the two forms of search tree arrange the Max and Min nodes differently
-- Paranoid tree policy treats the root layer's nodes as Max while any other nodes are Min
-- BRS does the similar way but instead of following the regular turn base, it combines all the opponents' node in one layer 
data TreeType = Paranoid | BRS deriving (Eq, Show, Read)

-- the new tree status applied during computing the Minimax search
type MGameTreeStatus = (-- the root layer player's index, should be static
                        PlayerIndex,
                        -- the current board state 
                        Board,
                         -- the list of positions of the internal board for each player
                        [[Pos]],
                        -- the total players, should be static
                        Int,
                        -- the alpha-beta pair, used for pruning the branches of the built search tree
                        AlphaBeta,
                        -- the choice of shallow minimax search, should be static
                        TreeType
                        )

-- the alpha and beta value, alpha value represents the solution of Max node, and beta for Min node
-- this pair is not consistent throughout the search tree, it might be switched, for instance, 
-- the maximum value of a subtree could be the minimum value of its parent
type AlphaBeta = (Int, Int)

-- the win state detection here is not just checking the internal state, it considers not only the normal winning condition, 
-- but also the potential blocking, therefore, a board state is defined as winning for a player if the corresponding goal base 
-- is filled and at least one of the pieces belongs to him/her
-- overall, this is a looser definition, and could allow suicidal action that make other players win, but it is faster, hence saving more time
winStateDetermine :: Colour -> Board -> Bool
winStateDetermine c b = let -- get the goal base positions on the external board of certain player 
                            goalPos = parMap rseq (reversion c) goalBase
                            -- and get the corresponding occupied state
                            goalBoardPos = evalState (do mapM getElement goalPos) b
                            -- check if the two conditions are satisfied
                            flag1 = isFull goalBoardPos
                            flag2 = existColour c goalBoardPos
                        in  flag1 `par` flag2 `pseq` (flag1 && flag2)
    where
        isFull :: [BoardPos] -> Bool
        isFull = foldr ((&&) . isOccupied) True
        
        existColour :: Colour -> [BoardPos] -> Bool
        existColour c bs = Just c `elem` map Board.getColour bs

--Enhancements------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 
-- addition to the standard work flow, some domain-independent techniques were added to fasten the search

-- return the distance between two positions
dist :: Pos -> Pos -> Double
dist (x1, y1) (x2, y2) = sqrt (fromIntegral (x1 - x2)^2 + fromIntegral (y1 - y2)^2)

-- a simple move evaluator of how close the changed piece is to the goal state, measuring the forward distance to the goal
-- this evaluation is more straightforward as it only considers the distance change
moveEvaluation :: (Pos, Pos) -> Double
moveEvaluation (p1, p2) = let dist1 = dist p1 (0, 6)
                              dist2 = dist p2 (0, 6)
                           in dist1 `par` dist2 `pseq` (dist1 - dist2) -- the larger the better

-- accept a list of moves and a distance-based heuristic, rank them from high to low, 
-- the one gives the largest distance increment will be placed at the front
moveOrder :: [Transform] -> [Transform]
moveOrder ms = let -- calculate the distance change for each move
                   result = assignDistance ms
                   -- rank them based on the distance change
                   sorted = sortBy (\(a, _) (b, _) -> compare b a) result
               in  map snd sorted -- omit the distance values
    where
        -- zip with the assoicated distance
        assignDistance :: [Transform] -> [(Double, Transform)]
        assignDistance ms = parMap rseq getDistance ms
        
        -- get the distance change of the internal position          
        getDistance :: Transform -> (Double, Transform)
        getDistance m@(from, to) = case getColour from of
                                    Nothing -> error "Invalid generated movement"
                                    Just co -> let internalPos = projectMove co m
                                                   dis = moveEvaluation internalPos
                                               in  (dis, m)

-- based on the colour of the movement, assign the corresponding player's index
assignIndex :: [Transform] -> Int -> [PlayerIndex]
assignIndex ms pn = parMap rseq (getPlayerIndex pn) ms
    where
        getPlayerIndex :: Int -> Transform -> PlayerIndex
        getPlayerIndex pn (from, _) = case getColour from of
                                        Nothing -> error "invalid movement"
                                        Just colour -> case colourIndex colour pn of
                                                            Nothing -> error "invalid colour"
                                                            Just index -> index

-- an enhancement that instead of investigating all nodes of a layer, only a certain number of nodes are allowed to be considered
-- this saves a lot of time but could miss some decisive moves, therefore, should be applied together with the more ordering
kbestpruning :: [Transform] -> [Transform]
kbestpruning tfs = take 5 $ moveOrder tfs -- 5 is a fixed value, and can be extended when the efficiency is significantly improved

-- a killer move is a move that was proved to be able to cause a prune at certain layer, therefore, could be useful to check them first when starting 
-- investigating a layer to cause earlier cutoff
-- normally, the killer moves are specifically existing on certain ply, therefore, each ply should store its own killer moves
-- here, for simplicity, the killer moves list is having the same length as the total players, and the killer moves are maintained based on player rather than certain depth

getKillerPair :: PlayerIndex -> State [KillerMoves] KillerMoves
getKillerPair pi = do ks <- get; return $ ks !! pi

setKillerPair :: PlayerIndex -> KillerMoves -> State [KillerMoves] ()
setKillerPair pi newk = do ks <- get; put (replace pi newk ks)

-- pick up the killer moves in a given move list and separate them
killerMoveTest :: KillerMoves -> [Transform] -> [Transform] -> ([Transform], [Transform])
killerMoveTest [] ms ss = (reverse ss, ms)
killerMoveTest (k:ks) ms ss = case elemIndex k ms of
                                Nothing  -> killerMoveTest ks ms ss
                                Just idx -> killerMoveTest ks (removeByIdx idx ms) (k:ss)

-- the killer moves are also updated throughout the search, when a new move is found to cause a cutoff, the old killer move that hasn't caused any cutoff recently will be replaced
-- in order to achieve that, the order will be switched based on the usage
updateKillerMovesOrder :: [Transform] -> PlayerIndex -> State [KillerMoves] ()
updateKillerMovesOrder [] pi = return ()
updateKillerMovesOrder ms pi = do kms <- getKillerPair pi
                                  let newKms = foldl (flip addKillerMove) kms ms -- the one applied recently will be pushed to the front
                                  setKillerPair pi newKms

-- add a new killer move to the list and remove the last entity of the list 
addKillerMove :: Transform -> KillerMoves -> KillerMoves
addKillerMove move kms = take 2 $ nub $ move:kms -- only keep limited number of killer moves, could be extended for more memory but will lead to slower computation

-- a combination of k-best pruning and killer moves
-- given a list of available movements, first take the existing killer moves away and reorder the movements based on distance increment
-- after that, append the found killer moves to the front of the list
reorderMovements :: [Transform] -> Int -> PlayerIndex -> State [KillerMoves] ([PlayerIndex], [Transform])
reorderMovements ms pn pi = do kms <- getKillerPair pi
                               let (appliedKms, remainMoves) = killerMoveTest kms ms []
                                   orderedMoves = kbestpruning remainMoves
                                   -- combine the found killer moves and the reordered moves
                                   reorderedMove = appliedKms `par` orderedMoves `pseq` (appliedKms ++ orderedMoves)
                                   -- also assign the player index for each move, for later indexing the killer move
                                   indices = assignIndex reorderedMove pn
                               -- besides, the existing killer moves are also needed to be reordered based on the recent usage
                               updateKillerMovesOrder appliedKms pi
                               return (indices, reorderedMove)

-- a modified version that handles movements generated by multiple players at the same time rather than just one (applied by BRS), 
reorderMovements2 :: [[Transform]] -> Int -> [PlayerIndex] -> State [KillerMoves] ([PlayerIndex], [Transform])
reorderMovements2 mss pn pis = do ls <- reorderMovements2' mss pn pis
                                  let -- transform them into the standard list forms
                                      (items1, items2) = unzip ls
                                      appliedKms = concat items1
                                      remainedMs = concat items2
                                      -- apply the enhancements regularly  
                                      orderedMoves = appliedKms `par` remainedMs `pseq` kbestpruning remainedMs
                                      reorderedMove = appliedKms ++ orderedMoves
                                      indices = assignIndex reorderedMove pn
                                  return (indices, reorderedMove)
    where
        -- return a list of pairs of found killer moves and remained moves
        reorderMovements2' :: [[Transform]] -> Int -> [PlayerIndex] -> State [KillerMoves] [(KillerMoves, [Transform])]
        reorderMovements2' [] _ _ = return []
        reorderMovements2' _ _ [] = return []
        reorderMovements2' (ms:mss) pn (pi:ps) = do kms <- getKillerPair pi
                                                    let pair@(appliedKms, _) = killerMoveTest kms ms []
                                                    updateKillerMovesOrder appliedKms pi
                                                    rest <- reorderMovements2' mss pn ps
                                                    return (pair:rest)

--Minimax tree search------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 

-- when it comes to BRS, the search tree becomes different where the second layer's node is no longer one opponent, but all opponents
otherPlayers :: Int -> PlayerIndex -> [PlayerIndex]
otherPlayers pn ri = filter (/=ri) [0 .. pn - 1]

-- therefore, it needs a different turn switch mechanism than the standard turn base
turnBaseBRS :: Int -> PlayerIndex -> PlayerIndex -> [PlayerIndex]
turnBaseBRS pn ri pi = if ri /= pi then [ri] else otherPlayers pn ri

-- for a certain player, return a list of available movements on the current board
mplayerMovesList :: MGameTreeStatus -> PlayerIndex -> [Transform]
mplayerMovesList (_, eboard, iboard, pn, _, _) pi = let -- the colour of the player's piece
                                                        colour = playerColour pi pn 
                                                        -- the internal positions of a player
                                                        ps = (iboard !! pi) 
                                                        -- revert those position to the external board
                                                        bs = colour `par` ps `pseq` parMap rseq (appendColour colour . reversion colour) ps 
                                                        -- generate available movements based on the external board state
                                                        ds = evalState (do mapM destinationList bs) eboard 
                                                    in  -- zip the start and the end, ensuring that they are listed in pairs
                                                        pairArrange bs ds 

-- the pruning is available based on evaluating the nodes below:
-- normally, when a Min node's (beta) value is less than or equal to (<=) any parent (Max)'s alpha value, that branch can be pruned
-- on the other hand, when a Max node's (alpha) value is larger than or equal to (>=) any parent (Min)'s beta value, the pruning can be also applied as well
-- in the multi-player version Minimax like Paranoid, the switch of Max and Min nodes are not done layer by layer, 
-- for instance, a Paranoid tree is having one Max layer and many of Min layers, 
-- but the regular pruning could be still applicable, the return is consistent that that Max node always returns alpha value while Min returns beta

--                  root          Given board state
--                 /    \
--                A      B        The new board states made by the root player
--               / \    / \
--              C   D  E   F      The new board states made by the first encountering player (one of the opponents, Paranoid), or all opponents (BRS)
--             /     \/     \
--            G     ....     H    The follow up layers (the next opponent, Paranoid) (or the root layer, BRS)


-- given a depth and tree status, and the player index to start with, 
-- generates the potential movements based on current board and send part of them to the next layer, either Max or Min, until reaching the bottom
-- where the board is eventually evaluated based on certain heuristic
-- after that, return the optimal move with its profit
mEvaluation :: Int -> MGameTreeStatus -> PlayerIndex -> State [KillerMoves] (Transform, Int)
-- pass to the evaluation function when reach the bottom of the set tree
mEvaluation 0 st pi = return (defaultMove, nEvaluation st pi)
mEvaluation height st@(ri, _, ps, pn, _, _) pi = do -- provide a list of possible movements that can be generated by the current layer
                                                    -- then apply move order, k-best pruning, and killer moves check
                                                    (indices, rmoves) <- reorderMovements (mplayerMovesList st pi) pn pi
                                                    -- determine the layer to put the resulting movements
                                                    if ri == pi then maxEvaluation (height - 1) st rmoves defaultMove indices
                                                    else minEvaluation (height - 1) st rmoves defaultMove indices

-- similar process, but with some difference
-- the movements are not only just generated by the root player but also all other opponents at the same time
mEvaluation2 :: Int -> MGameTreeStatus -> [PlayerIndex] -> State [KillerMoves] (Transform, Int)
mEvaluation2 height st@(ri, _, ps, pn, _, _) pis = do (indices, rmoves) <- reorderMovements2 (parMap rseq (mplayerMovesList st) pis) pn pis
                                                      -- if only the root player's turn, then call them as Max nodes
                                                      if pis == [ri] then maxEvaluation (height - 1) st rmoves defaultMove indices
                                                      -- otherwise, are all Min layer's nodes
                                                      else minEvaluation (height - 1) st rmoves defaultMove indices

-- the difference between two minimax search: the Paranoid search follows the regular order base, 
-- while the BRS considers all players other than the root as a layer, so it actually evaluates a list of boards from different players 
treeSearch :: Int -> MGameTreeStatus -> PlayerIndex -> State [KillerMoves] Int
-- since it is not necessary to know about the best movement from other layers, except for the root's, 
-- here they are ignored, only the corresponding score is returned
treeSearch 0 st pi = do (_, score) <- mEvaluation 0 st pi; return score
treeSearch h st@(ri, _, _, pn, _, Paranoid) pi = do (_, score) <- mEvaluation h st (turnBase pn pi); return score
treeSearch h st@(ri, _, _, pn, _, BRS) pi = do (_, score) <- mEvaluation2 h st (turnBaseBRS pn ri pi); return score

-- for handling the Max nodes 
-- here first sync the game status based on the given moves, and then passes it to the next layer until reaching the bottom (pre-set depth)  
-- while maintaining the best score and the corresponding movement                                                       
maxEvaluation :: Int -> MGameTreeStatus -> [Transform] -> Transform -> [PlayerIndex] -> State [KillerMoves] (Transform, Int)
-- Max layer should return alpha value
maxEvaluation _ (_, _, _, _, (alpha, _), _) [] bestMove _ = return (bestMove, alpha) 
maxEvaluation _ (_, _, _, _, (alpha, _), _) _ bestMove [] = return (bestMove, alpha)
maxEvaluation height st@(ri, eboard, iboards, pn, ab@(alpha, beta), tt) (m:ms) bestMove (pi:pis) =
                                                               -- first update the status for the next layer
                                                        do let currentColour = playerColour pi pn
                                                               newiboard = flipBoard (iboards !! pi) (projectMove currentColour m)
                                                               newiboards = replace pi newiboard iboards
                                                               neweboard = repaintPath eboard m
                                                               -- generate the status to be delivered to the next layer
                                                               nextTurnState = neweboard `par` newiboards `pseq` (ri, neweboard, newiboards, pn, ab, tt)
                                                           -- pass the status to the next layer and retrieve the best score from that layer
                                                           score <- treeSearch height nextTurnState pi
                                                           -- retrieve the current player's killer moves
                                                           kp <- getKillerPair pi
                                                           -- compare the score from layers below with the existing alpha value
                                                           -- decide if needed to update the best move and score
                                                           let (newBestMove, newAlpha) = if score >= alpha then (m, score) else (bestMove, alpha)
                                                           -- prune the branch if found a proof that the parent won't choose this branch
                                                           if newAlpha >= beta then do -- update the killer moves when pruning is occurred
                                                                                       setKillerPair pi (addKillerMove m kp) 
                                                                                       -- pruning occurs
                                                                                       return (bestMove, beta)
                                                           else -- compute the next movement in the list at the same layer
                                                                maxEvaluation height (ri, eboard, iboards, pn, (newAlpha, beta), tt) ms newBestMove pis
                                                                

-- similar to above but different in comparing the returned score
minEvaluation :: Int -> MGameTreeStatus -> [Transform] -> Transform -> [PlayerIndex] -> State [KillerMoves] (Transform, Int)
-- Min layer returns beta value
minEvaluation _ (_, _, _, _, (_, beta), _) [] bestMove _ = return (bestMove, beta) 
minEvaluation _ (_, _, _, _, (_, beta), _) _ bestMove [] = return (bestMove, beta)
minEvaluation height st@(ri, eboard, iboards, pn, ab@(alpha, beta), tt) (m:ms) bestMove (pi:pis) =

                                                        do let currentColour = playerColour pi pn
                                                               newiboard = flipBoard (iboards !! pi) (projectMove currentColour m)
                                                               newiboards = replace pi newiboard iboards
                                                               neweboard = repaintPath eboard m
                                                               nextTurnState = neweboard `par` newiboards `pseq` (ri, neweboard, newiboards, pn, ab, tt)

                                                           score <- treeSearch height nextTurnState pi
                                                           kp <- getKillerPair pi
                                                           let (newBestMove, newBeta) = if score <= beta then (m, score) else (bestMove, beta) -- update the beta value

                                                           if newBeta <= alpha then do setKillerPair pi (addKillerMove m kp) 
                                                                                       return (bestMove, alpha)
                                                           else minEvaluation height (ri, eboard, iboards, pn, (alpha, newBeta), tt) ms newBestMove pis

-- evaluate the bottom node (where the depth is equal to 0) of the search tree
-- since the evaluation should be made based on the root's perspective, the evaluation of the other layer player is done by evaluating how the root player could benefit
nEvaluation :: MGameTreeStatus -> PlayerIndex -> Int 
nEvaluation st@(ri, eboard, iboard, pn, _, _) pi
    -- only care about the root layer's score, if root player wins, returns the maximum gain
    | winStateDetermine rolour eboard = 28 
    -- if no player winning, then just evaluate normally based on board evaluator
    | ri == pi = centroid (iboard !! ri)
    -- for other players, how a board is evaluated is based on how the root player could play on this board
    | otherwise = let ms = mplayerMovesList st ri    
                      rs = iboard !! ri
                      nbs = rolour `par` ms `par` rs `pseq` parMap rseq (flipBoard rs . projectMove rolour) ms
                      scores = parMap rseq centroid nbs
                  in  if null scores then error (show eboard) else maximum scores
    where
        rolour = playerColour ri pn